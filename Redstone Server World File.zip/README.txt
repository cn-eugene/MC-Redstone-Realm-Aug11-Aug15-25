how to add a world to your world files (java Minecraft on windows) (bedrock won't work, nor will consoles)
1. press windows + R and type %appdata% into the pop-up
2. click into the .minecraft folder
3. drag the world file into the saves folder
4. boot up Minecraft